-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 28, 2014 at 08:26 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `appointment`
--

-- --------------------------------------------------------

--
-- Table structure for table `jqcalendar`
--

CREATE TABLE IF NOT EXISTS `jqcalendar` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Subject` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `Location` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `Description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `IsAllDayEvent` smallint(6) NOT NULL,
  `Color` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `RecurringRule` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `jqcalendar`
--

INSERT INTO `jqcalendar` (`Id`, `Subject`, `Location`, `Description`, `StartTime`, `EndTime`, `IsAllDayEvent`, `Color`, `RecurringRule`) VALUES
(1, 'Meeting with steve', NULL, NULL, '2014-06-24 10:00:00', '2014-06-24 11:00:00', 0, NULL, NULL),
(2, 'Meeting with jessica', NULL, NULL, '2014-06-24 13:00:00', '2014-06-24 14:00:00', 0, NULL, NULL),
(3, 'Meeting with robert', NULL, NULL, '2014-06-24 07:30:00', '2014-06-24 08:30:00', 0, NULL, NULL),
(5, 'Meeting with john', NULL, NULL, '2014-06-24 16:30:00', '2014-06-24 17:30:00', 0, NULL, NULL),
(6, 'Meeting with stephen', NULL, NULL, '2014-06-26 15:00:00', '2014-06-26 16:00:00', 0, NULL, NULL),
(7, 'Meeting with justin', NULL, NULL, '2014-06-27 12:00:00', '2014-06-27 13:00:00', 0, NULL, NULL),
(8, 'Meeting with steve', NULL, NULL, '2014-06-28 08:00:00', '2014-06-28 09:00:00', 0, NULL, NULL),
(9, 'Meeting with alphonso', NULL, NULL, '2014-06-28 15:00:00', '2014-06-28 16:00:00', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `desciption` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(1) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `desciption`, `username`, `password`, `level`, `created_on`, `email`, `phonenumber`) VALUES
(1, 'Asif', 'my name is asif', 'asif1234', '9935461220', '2', '2014-06-23 15:49:28', 'asifk.isme11@gmail.com ', '99354613201'),
(15, 'Imran', 'name is imran', 'imran123', '9450090783', '1', '2014-06-24 23:59:03', 'imran@gmail.com', '9450090783'),
(21, 'Tasnim', 'tasnim is my name', 'tasnim123', '9450090786', '3', '2014-06-27 11:26:55', 'tasnim@gmail.com', '9450090787'),
(22, 'Izhar', 'izhar is my name', 'izhar123', '9935461321', '4', '2014-06-27 11:28:12', 'izhar@gmail.com', '9935461321');
