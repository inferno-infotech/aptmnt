-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 17, 2014 at 03:58 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `appointment`
--

-- --------------------------------------------------------

--
-- Table structure for table `day`
--

CREATE TABLE IF NOT EXISTS `day` (
  `day_id` int(11) NOT NULL AUTO_INCREMENT,
  `week_id` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `day` varchar(255) NOT NULL,
  PRIMARY KEY (`day_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `day`
--

INSERT INTO `day` (`day_id`, `week_id`, `date`, `day`) VALUES
(1, 1, '16', 'Wednesday'),
(2, 1, '19', 'Saturday');

-- --------------------------------------------------------

--
-- Table structure for table `jqcalendar`
--

CREATE TABLE IF NOT EXISTS `jqcalendar` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Subject` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `Location` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `Description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `IsAllDayEvent` smallint(6) NOT NULL,
  `Color` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `RecurringRule` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `Customername` varchar(255) NOT NULL,
  `Customeremail` varchar(255) NOT NULL,
  `Customerphone` varchar(255) NOT NULL,
  `Customerusername` varchar(255) NOT NULL,
  `Customerdescription` varchar(255) NOT NULL,
  `CustomerStatus` int(2) NOT NULL,
  `Leads` int(2) NOT NULL,
  `Level` varchar(2) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `jqcalendar`
--

INSERT INTO `jqcalendar` (`Id`, `Subject`, `Location`, `Description`, `StartTime`, `EndTime`, `IsAllDayEvent`, `Color`, `RecurringRule`, `Customername`, `Customeremail`, `Customerphone`, `Customerusername`, `Customerdescription`, `CustomerStatus`, `Leads`, `Level`) VALUES
(1, NULL, NULL, NULL, '2014-07-16 09:00:00', '2014-07-16 10:00:00', 0, NULL, NULL, '', '', '', '', '', 0, 0, ''),
(2, NULL, NULL, NULL, '2014-07-16 11:00:00', '2014-07-16 12:00:00', 0, NULL, NULL, '', '', '', '', '', 0, 0, ''),
(3, NULL, NULL, NULL, '2014-07-19 12:00:00', '2014-07-19 01:00:00', 0, NULL, NULL, '', '', '', '', '', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `time`
--

CREATE TABLE IF NOT EXISTS `time` (
  `time_id` int(11) NOT NULL AUTO_INCREMENT,
  `Day_id` int(11) NOT NULL,
  `Week_id` int(11) NOT NULL,
  `Start_time` varchar(255) NOT NULL,
  `End_time` varchar(255) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `customerlocation` varchar(255) NOT NULL,
  `customeremail` varchar(255) NOT NULL,
  `customerphone` varchar(255) NOT NULL,
  `customerusername` varchar(255) NOT NULL,
  `customerdescription` varchar(255) NOT NULL,
  PRIMARY KEY (`time_id`),
  KEY `Day_id` (`Day_id`),
  KEY `Day_id_2` (`Day_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `time`
--

INSERT INTO `time` (`time_id`, `Day_id`, `Week_id`, `Start_time`, `End_time`, `Title`, `customerlocation`, `customeremail`, `customerphone`, `customerusername`, `customerdescription`) VALUES
(1, 1, 1, '9', '10', '', '', '', '', '', ''),
(2, 1, 1, '11', '12', '', '', '', '', '', ''),
(3, 2, 1, '12', '1', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `desciption` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(5) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `levelcreateleads` varchar(255) NOT NULL,
  `leadsusername` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `desciption`, `username`, `password`, `level`, `created_on`, `email`, `phonenumber`, `levelcreateleads`, `leadsusername`) VALUES
(1, 'Asif', 'Manager', 'asif123', '9889262973', '1', '2014-07-03 09:07:08', 'asifk.isme11@gmail.com ', '9889262973', '', ''),
(13, 'Salman', 'Manager', 'sallu1234', '9445090783', 'leads', '2014-07-08 15:00:10', 'salman@gmail.com', '9445090783', '2', ''),
(5, 'Krishna', 'Manager', 'Kris123', '9450090786', 'leads', '2014-07-08 10:38:54', 'Kris@gmail.com', '9450090786', '2', ''),
(6, 'Tasnim', 'Manager', 'Tasnim123', '9450090783', '2', '2014-07-08 11:51:32', 'Tasnim@gmail.com', '9450090783', '', ''),
(9, 'Appu', 'Manager', 'Appu123', '9889262973', '2', '2014-07-08 13:25:51', 'appu@gmail.com', '9450090786', '', ''),
(10, 'Salman', 'Manager', 'sallu123', '9935461320', '2', '2014-07-08 13:29:00', 'sallu@gmail.com', '9935461320', '', ''),
(11, 'Amir', 'Manager', 'Amir123', '9935461320', '3', '2014-07-08 13:29:55', 'Amir@gmail.com', '9935461320', '', ''),
(12, 'Soni', 'Manager', 'Soni123', '123456', '3', '2014-07-08 13:31:51', 'soni@gmail.com', '9935461320', '', ''),
(14, 'Sally', 'Manager', 'sally123', '958009445', 'leads', '2014-07-08 15:18:32', 'sally@gmail.com', '958009445', '2,leadsusernameAppu123', ''),
(15, 'Rita', 'Manager', 'rita123', '9935461320', 'leads', '2014-07-08 15:32:07', 'rita@gmail.com', '9935461320', '2', '');

-- --------------------------------------------------------

--
-- Table structure for table `week`
--

CREATE TABLE IF NOT EXISTS `week` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `week` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `week`
--

INSERT INTO `week` (`id`, `week`, `year`, `month`) VALUES
(1, '29', '2014', '07');
