-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 25, 2014 at 11:00 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `appointment`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `desciption` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(5) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `levelcreateleads` varchar(255) NOT NULL,
  `leadsusername` varchar(255) NOT NULL,
  `Parentlevelid` varchar(255) NOT NULL,
  `levelfourack` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `desciption`, `username`, `password`, `level`, `created_on`, `email`, `phonenumber`, `levelcreateleads`, `leadsusername`, `Parentlevelid`, `levelfourack`) VALUES
(1, 'Asif', 'Manager', 'asif123', '9889262973', '1', '2014-07-03 09:07:08', 'asifk.isme11@gmail.com ', '9889262973', '', '', '', ''),
(13, 'Salman', 'Manager', 'sallu1234', '9445090783', '4', '2014-07-08 15:00:10', 'salman@gmail.com', '9445090783', '2', '', '34', ''),
(30, 'Mina', 'Manager', 'Mina123', '9889262982', '3', '2014-07-21 16:58:46', 'mina@gmail.com', '9889262983', '', 'Tasnim123', '6', ''),
(6, 'Tasnim', 'Manager', 'Tasnim123', '9450090783', '2', '2014-07-08 11:51:32', 'Tasnim@gmail.com', '9450090783', '', '', '', ''),
(9, 'Appu', 'Manager', 'Appu123', '9889262973', '3', '2014-07-08 13:25:51', 'appu@gmail.com', '9450090786', '', '', '33', ''),
(17, 'Masim', 'Manager', 'masim123', '944556789', '4', '2014-07-18 16:39:12', 'masim@gmail.com', '9935461320', '3', 'Soni123', '30', ''),
(11, 'Amir', 'Manager', 'Amir123', '9935461320', '2', '2014-07-08 13:29:55', 'Amir@gmail.com', '9935461320', '', '', '', ''),
(12, 'Soni', 'Manager', 'Soni123', '123456', '3', '2014-07-08 13:31:51', 'soni@gmail.com', '9935461320', '', '', '6', ''),
(14, 'Sally', 'Manager', 'sally123', '958009445', '4', '2014-07-08 15:18:32', 'sally@gmail.com', '958009445', '2,leadsusernameAppu123', '', '', ''),
(15, 'Rita', 'Manager', 'rita123', '9935461320', '4', '2014-07-08 15:32:07', 'rita@gmail.com', '9935461320', '2', '', '9', ''),
(18, 'Mohan', 'Manager', 'mohan123', '9450090786', '3', '2014-07-18 20:00:19', 'mohan@gmail.com', '9450090786', '', '', '6', ''),
(19, 'Naresh', 'Engineer', 'naresh123', '95090786', '2', '2014-07-18 20:03:05', 'naresh@gmail.com', '9935461324', '', '', '', ''),
(20, 'Rehman', 'Engineer', 'Rehman123', '9935461325', '2', '2014-07-18 20:19:33', 'rehman@gmail.com', '9935461327', '', '', '', ''),
(23, 'Sonali', 'Manager', 'sonali123', '9889262932', '3', '2014-07-19 14:52:09', 'sonali@gmail.com', '9889262933', '', 'Tasnim123', '6', ''),
(22, 'Dushyant', 'Manager', 'dushyant123', '9935461331', '2', '2014-07-19 11:39:01', 'dushyant@gmail.com', '9935461331', '', 'asif123', '1', ''),
(24, 'Sonali1', 'Manager', 'sonali234', '9889262934', '4', '2014-07-19 14:53:21', 'sonali1@gmail.com', '9889262934', '', 'Tasnim123', '6', '1'),
(25, 'Sonali123', 'Manager', 'Sonali123', '9935461337', '4', '2014-07-19 15:07:10', 'sonali@gmail.com', '9935461337', '', 'Tasnim123', '6', ''),
(26, 'Sonal', 'Manager', 'sonal123', '9935461337', '4', '2014-07-19 15:18:20', 'sonal@gmail.com', '9935461337', '', 'Tasnim123', '6', '1'),
(27, 'Sonal12', 'Manager', 'Sonal123', '9935461338', '3', '2014-07-19 15:19:16', 'Sonal@gmail.com', '9889262993', '', 'Tasnim123', '6', ''),
(28, 'Momin', 'manager', 'Momin123', '9935461340', '3', '2014-07-19 15:22:01', 'momin@gmail.com', '9935461440', '', 'asif123', '1', ''),
(29, 'Moman', 'manager', 'moman123', '9935461341', '3', '2014-07-19 15:33:45', 'moman@gmail.com', '9935461441', '', 'Tasnim123', '6', ''),
(32, 'Dashing', 'Manager', 'dash123', '9935461385', '2', '2014-07-21 18:41:17', '9935461375', '9450090794', '', 'asif123', '1', ''),
(33, 'Disha', 'Manager', 'disha123', '9889262983', '3', '2014-07-21 18:42:07', 'disha@gmail.com', '9889262984', '', 'asif123', '1', ''),
(34, 'Dash', 'Manager', 'dash1234', '9889262999', '2', '2014-07-21 18:57:14', 'dash@gmail.com', '9889262992', '', 'asif123', '1', ''),
(35, 'Dicky', 'Manager', 'Dick123', '993546132012', '3', '2014-07-21 18:58:03', 'dick@gmail.com', '988926297345', '', 'asif123', '1', ''),
(36, 'Molak', 'Manager', 'molak123', '9889262945', '3', '2014-07-21 20:00:31', 'molak@gmail.com', '9889262945', '', 'Tasnim123', '6', ''),
(37, 'Shakil', 'Comedian', 'shakil123', '9450090788', '4', '2014-07-22 11:57:38', 'shakil@gmail.com', '958009931', '', 'Appu123', '9', '');
